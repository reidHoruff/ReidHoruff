﻿namespace serialCOMM
{
    partial class serialForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.RXTXSplitContainer = new System.Windows.Forms.SplitContainer();
            this.RXClearLink = new System.Windows.Forms.LinkLabel();
            this.recievedTextBox = new System.Windows.Forms.TextBox();
            this.TXClearLink = new System.Windows.Forms.LinkLabel();
            this.sentTextBox = new System.Windows.Forms.TextBox();
            this.enableButton = new System.Windows.Forms.Button();
            this.bitrateComboBox = new System.Windows.Forms.ComboBox();
            this.toSendTextBox = new System.Windows.Forms.TextBox();
            this.sendButton = new System.Windows.Forms.Button();
            this.portComboBox = new System.Windows.Forms.ComboBox();
            this.serialPort = new System.IO.Ports.SerialPort(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.RXTXSplitContainer)).BeginInit();
            this.RXTXSplitContainer.Panel1.SuspendLayout();
            this.RXTXSplitContainer.Panel2.SuspendLayout();
            this.RXTXSplitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "TX";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "RX";
            // 
            // RXTXSplitContainer
            // 
            this.RXTXSplitContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.RXTXSplitContainer.Location = new System.Drawing.Point(12, 68);
            this.RXTXSplitContainer.Name = "RXTXSplitContainer";
            // 
            // RXTXSplitContainer.Panel1
            // 
            this.RXTXSplitContainer.Panel1.Controls.Add(this.RXClearLink);
            this.RXTXSplitContainer.Panel1.Controls.Add(this.label1);
            this.RXTXSplitContainer.Panel1.Controls.Add(this.recievedTextBox);
            // 
            // RXTXSplitContainer.Panel2
            // 
            this.RXTXSplitContainer.Panel2.Controls.Add(this.TXClearLink);
            this.RXTXSplitContainer.Panel2.Controls.Add(this.label2);
            this.RXTXSplitContainer.Panel2.Controls.Add(this.sentTextBox);
            this.RXTXSplitContainer.Size = new System.Drawing.Size(653, 364);
            this.RXTXSplitContainer.SplitterDistance = 187;
            this.RXTXSplitContainer.SplitterWidth = 2;
            this.RXTXSplitContainer.TabIndex = 22;
            // 
            // RXClearLink
            // 
            this.RXClearLink.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RXClearLink.AutoSize = true;
            this.RXClearLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.RXClearLink.Location = new System.Drawing.Point(153, 4);
            this.RXClearLink.Name = "RXClearLink";
            this.RXClearLink.Size = new System.Drawing.Size(31, 13);
            this.RXClearLink.TabIndex = 4;
            this.RXClearLink.TabStop = true;
            this.RXClearLink.Text = "Clear";
            this.RXClearLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.RXClearLink_LinkClicked);
            // 
            // recievedTextBox
            // 
            this.recievedTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.recievedTextBox.BackColor = System.Drawing.Color.White;
            this.recievedTextBox.Enabled = false;
            this.recievedTextBox.Location = new System.Drawing.Point(3, 20);
            this.recievedTextBox.MinimumSize = new System.Drawing.Size(0, 40);
            this.recievedTextBox.Multiline = true;
            this.recievedTextBox.Name = "recievedTextBox";
            this.recievedTextBox.ReadOnly = true;
            this.recievedTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.recievedTextBox.Size = new System.Drawing.Size(181, 341);
            this.recievedTextBox.TabIndex = 1;
            // 
            // TXClearLink
            // 
            this.TXClearLink.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TXClearLink.AutoSize = true;
            this.TXClearLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.TXClearLink.Location = new System.Drawing.Point(432, 4);
            this.TXClearLink.Name = "TXClearLink";
            this.TXClearLink.Size = new System.Drawing.Size(31, 13);
            this.TXClearLink.TabIndex = 23;
            this.TXClearLink.TabStop = true;
            this.TXClearLink.Text = "Clear";
            this.TXClearLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.TXClearLink_LinkClicked);
            // 
            // sentTextBox
            // 
            this.sentTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.sentTextBox.BackColor = System.Drawing.Color.White;
            this.sentTextBox.Enabled = false;
            this.sentTextBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.sentTextBox.Location = new System.Drawing.Point(3, 20);
            this.sentTextBox.MinimumSize = new System.Drawing.Size(0, 40);
            this.sentTextBox.Multiline = true;
            this.sentTextBox.Name = "sentTextBox";
            this.sentTextBox.ReadOnly = true;
            this.sentTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.sentTextBox.Size = new System.Drawing.Size(458, 341);
            this.sentTextBox.TabIndex = 1;
            // 
            // enableButton
            // 
            this.enableButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enableButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.enableButton.Location = new System.Drawing.Point(15, 12);
            this.enableButton.Name = "enableButton";
            this.enableButton.Size = new System.Drawing.Size(75, 23);
            this.enableButton.TabIndex = 13;
            this.enableButton.Text = "Start";
            this.enableButton.UseVisualStyleBackColor = true;
            this.enableButton.Click += new System.EventHandler(this.enableButton_Click);
            // 
            // bitrateComboBox
            // 
            this.bitrateComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.bitrateComboBox.FormattingEnabled = true;
            this.bitrateComboBox.Location = new System.Drawing.Point(96, 13);
            this.bitrateComboBox.Name = "bitrateComboBox";
            this.bitrateComboBox.Size = new System.Drawing.Size(85, 21);
            this.bitrateComboBox.TabIndex = 14;
            // 
            // toSendTextBox
            // 
            this.toSendTextBox.AllowDrop = true;
            this.toSendTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.toSendTextBox.Enabled = false;
            this.toSendTextBox.Location = new System.Drawing.Point(15, 40);
            this.toSendTextBox.Name = "toSendTextBox";
            this.toSendTextBox.Size = new System.Drawing.Size(569, 20);
            this.toSendTextBox.TabIndex = 15;
            this.toSendTextBox.Click += new System.EventHandler(this.toSendTextBox_Click);
            this.toSendTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.toSendTextBox_KeyPress);
            // 
            // sendButton
            // 
            this.sendButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.sendButton.Enabled = false;
            this.sendButton.Location = new System.Drawing.Point(590, 38);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(75, 23);
            this.sendButton.TabIndex = 16;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = true;
            this.sendButton.Click += new System.EventHandler(this.sendButton_Click);
            // 
            // portComboBox
            // 
            this.portComboBox.FormattingEnabled = true;
            this.portComboBox.Location = new System.Drawing.Point(187, 13);
            this.portComboBox.Name = "portComboBox";
            this.portComboBox.Size = new System.Drawing.Size(95, 21);
            this.portComboBox.TabIndex = 19;
            // 
            // serialPort
            // 
            this.serialPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort_DataReceived);
            // 
            // serialForm
            // 
            this.ClientSize = new System.Drawing.Size(677, 444);
            this.Controls.Add(this.RXTXSplitContainer);
            this.Controls.Add(this.portComboBox);
            this.Controls.Add(this.sendButton);
            this.Controls.Add(this.toSendTextBox);
            this.Controls.Add(this.bitrateComboBox);
            this.Controls.Add(this.enableButton);
            this.MinimumSize = new System.Drawing.Size(400, 280);
            this.Name = "serialForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Frosted Serial";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.serialForm_FormClosing);
            this.RXTXSplitContainer.Panel1.ResumeLayout(false);
            this.RXTXSplitContainer.Panel1.PerformLayout();
            this.RXTXSplitContainer.Panel2.ResumeLayout(false);
            this.RXTXSplitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RXTXSplitContainer)).EndInit();
            this.RXTXSplitContainer.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.SplitContainer RXTXSplitContainer;
        public System.Windows.Forms.TextBox recievedTextBox;
        public System.Windows.Forms.TextBox sentTextBox;
        public System.Windows.Forms.Button enableButton;
        public System.Windows.Forms.ComboBox bitrateComboBox;
        public System.Windows.Forms.TextBox toSendTextBox;
        public System.Windows.Forms.Button sendButton;
        public System.Windows.Forms.ComboBox portComboBox;
        public System.IO.Ports.SerialPort serialPort;
        private System.Windows.Forms.LinkLabel RXClearLink;
        private System.Windows.Forms.LinkLabel TXClearLink;

    }
}

