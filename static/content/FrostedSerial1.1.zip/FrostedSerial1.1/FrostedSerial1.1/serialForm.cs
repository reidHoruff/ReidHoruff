﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace serialCOMM
{ 
    public partial class serialForm : Form
    {
        string rxString, txString;
        string defaultBitRate = "9600";
        string defaultPort = "COM3";
        string[] bitRate = { "300", "1200", "2400", "4800", "9600", "14400", "14200", "28800", "38400", "57600", "115200" };
        string[] ports = { "COM1", "COM2", "COM3" };
        
        public serialForm()
        {
            InitializeComponent();
            adjustRXTXContainer(true);

            /*add combobox values*/
            bitrateComboBox.Items.AddRange(bitRate);
            portComboBox.Items.AddRange(ports);

            /*select defaults*/
            bitrateComboBox.SelectedItem = defaultBitRate;
            portComboBox.SelectedItem = defaultPort;
        }

        private void serialPort_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            rxString = serialPort.ReadExisting();
            this.Invoke(new EventHandler(DisplayText));

            /*string temp = serialPort.ReadExisting();

            for (int x = 0; x < temp.Length; x++)
            {
                rxString = temp.Substring(0, x);
                this.Invoke(new EventHandler(DisplayText));
            }*/
        }

        private void DisplayText(object sender, EventArgs e)
        {
            recievedTextBox.AppendText(rxString);
        }

        private void serialForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }

        private void enableButton_Click(object sender, EventArgs e)
        {
            if (serialPort.IsOpen) /*time to close the port*/
            {
                try
                {
                    serialPort.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occured while trying to close " + serialPort.PortName, "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                enableButton.Text = "Start";

                recievedTextBox.Enabled = false;
                sentTextBox.Enabled = false;
                sendButton.Enabled = false;
                toSendTextBox.Enabled = false;

                bitrateComboBox.Enabled = true;
                portComboBox.Enabled = true;
            }

            else /*time to open the port*/
            {
                serialPort.PortName = (string)portComboBox.SelectedItem;
                serialPort.BaudRate = Int32.Parse((string)bitrateComboBox.SelectedItem);

                try
                {
                    serialPort.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("The Port " + serialPort.PortName + " does not exits or cannot be opened", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                enableButton.Text = "Stop";
                recievedTextBox.Enabled = true;
                sentTextBox.Enabled = true;
                sendButton.Enabled = true;
                toSendTextBox.Enabled = true;

                bitrateComboBox.Enabled = false;
                portComboBox.Enabled = false;
            }
        }

        private void sendButton_Click(object sender, EventArgs e)
        {
            if (!serialPort.IsOpen)
            {
                return;
            }

            txString = toSendTextBox.Text;
            serialPort.Write(txString);
            sentTextBox.AppendText(txString + "\r\n");
        }

        /*can align RX/TX text boxes either vertivally or horizontally */
        public void adjustRXTXContainer(bool isVertical)
        {
            if (isVertical)
            {
                RXTXSplitContainer.Orientation = System.Windows.Forms.Orientation.Vertical;
                RXTXSplitContainer.SplitterDistance = RXTXSplitContainer.Width / 2;
            }

            else
            {
                RXTXSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
                RXTXSplitContainer.SplitterDistance = RXTXSplitContainer.Height / 2;
            }
        }

        private void toSendTextBox_Click(object sender, EventArgs e)
        {
            toSendTextBox.SelectAll();
        }

        private void toSendTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            /* if Enter key is pressed */
            if (e.KeyChar == (char)13)
            {
                sendButton.PerformClick();
            }
        }

        private void RXClearLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            recievedTextBox.Clear();
        }

        private void TXClearLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            sentTextBox.Clear();
        }
    }
}
